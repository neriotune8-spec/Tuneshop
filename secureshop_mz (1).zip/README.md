# SecureShop-MZ — Loja pronta para deploy (WhatsApp checkout)

Esta é uma versão completa e pronta para você colocar no ar. O site usa um fluxo de compra via WhatsApp (link wa.me) e instruções manuais para pagamentos via e‑Mola, EMPZ e BIM.

## O que está incluído
- `server.js` — backend em Node/Express que serve a API e ficheiros públicos.
- `public/index.html` — frontend simples que lista produtos e abre WhatsApp com mensagem pré-preenchida.
- `db/products.json` — ficheiro com produtos iniciais.
- `Dockerfile`, `docker-compose.yml` — para deploy fácil com Docker.
- `nginx.conf` — exemplo de reverse proxy com SSL (Let's Encrypt).
- `.env.sample` — variáveis de ambiente a configurar.
- `README.md` — este ficheiro.

## Como usar localmente (rápido)
1. Copia os ficheiros para um servidor/VPS ou ao teu computador.
2. Instala Node.js (versão 18+ recomendada).
3. No terminal, dentro da pasta do projecto:
   ```bash
   npm install
   ADMIN_KEY='troca_por_chave_segura' node server.js
   ```
4. Abre `http://localhost:3000` no teu browser.

## Deploy com Docker (recomendado)
1. Instala Docker e Docker Compose no servidor.
2. Copia o projecto para o VPS.
3. Edita `docker-compose.yml` (altera `ADMIN_KEY` e `WHATSAPP_PHONE`).
4. Executa:
   ```bash
   docker compose up -d --build
   ```
5. Usa `nginx` como reverse proxy e configura `yourdomain.tld` apontando para o IP do servidor.
6. Usa Certbot para gerar certificados Let's Encrypt:
   ```bash
   sudo apt install certbot python3-certbot-nginx
   sudo certbot --nginx -d yourdomain.tld
   ```

## Configurações importantes
- Altera `ADMIN_KEY` para uma chave forte antes de colocar online.
- Altera `WHATSAPP_PHONE` para o teu número se for diferente.
- Não comites credenciais em repositórios públicos.
- Para pagamentos automáticos (integração com e-Mola/BIM), precisamos de contas comerciais e APIs dos serviços.

## Personalização e próximos passos
- Posso personalizar as imagens, textos e adicionar autenticação real (login) e painel de encomendas.
- Posso ajudar com o deploy completo se me deres acesso ao VPS ou domínios (opcional).

Suporte: WhatsApp vendas (pré-configurado) => +258 879 459 513
