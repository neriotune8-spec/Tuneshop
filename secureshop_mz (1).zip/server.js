const express = require('express');
const fs = require('fs');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bodyParser = require('body-parser');

const app = express();
app.use(helmet());
app.use(bodyParser.json());
app.use(express.static('public'));

const DB_FILE = path.join(__dirname, 'db', 'products.json');
const ADMIN_KEY = process.env.ADMIN_KEY || 'mudar_este_seguro_token';
const WHATSAPP_PHONE = process.env.WHATSAPP_PHONE || '258879459513';

function readDb(){ try{ return JSON.parse(fs.readFileSync(DB_FILE,'utf8')); }catch(e){ return []; } }
function writeDb(data){ fs.writeFileSync(DB_FILE, JSON.stringify(data,null,2)); }

app.get('/api/products', (req,res)=>{ res.json(readDb()); });

app.post('/api/admin/products', (req,res)=>{
  if(req.headers['x-admin-key'] !== ADMIN_KEY) return res.status(401).json({error:'unauthorized'});
  const db = readDb();
  const item = { id: Date.now(), title: String(req.body.title).slice(0,200), price: Number(req.body.price) || 0, desc: String(req.body.desc||'').slice(0,2000) };
  db.push(item); writeDb(db);
  res.json(db);
});

// Endpoint to update whatsapp phone (protected)
app.post('/api/admin/whatsapp', (req,res)=>{
  if(req.headers['x-admin-key'] !== ADMIN_KEY) return res.status(401).json({error:'unauthorized'});
  // This demo keeps phone in env; in production store it in DB or secret store
  res.status(501).json({error:'not_implemented','message':'Change WHATSAPP_PHONE in environment variables'});
});

const port = process.env.PORT||3000; app.listen(port, ()=>console.log('Server on',port));
